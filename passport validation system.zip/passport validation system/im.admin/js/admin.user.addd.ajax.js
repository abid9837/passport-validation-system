


//  add user
function admin_user_add() { 
    event.preventDefault();

    // get user data from input firld form
    var Aplication_Date = jQuery('#Aplication_Date').val();
    var Passport_Number = jQuery('#Passport_Number').val();
    var Request_Number = jQuery('#Request_Number').val();
    var user_country = jQuery('#user_country').val();
    var Name_of_Owner = jQuery('#Name_of_Owner').val();
    var Consulate = jQuery('#Consulate').val();
    var Days_Stay = jQuery('#Days_Stay').val();
    var Type_of_Procedure = jQuery('#Type_of_Procedure').val();
    var Validity = jQuery('#Validity').val();

    // ajax form data insert 
    $.ajax({
        type: "POST",
        url: "http://localhost/passport%20validation%20system/im.admin/ajax.php/add.new.user.ajax.php",
        data: {

            Aplication_Date:Aplication_Date,
            Passport_Number:Passport_Number,
            Request_Number:Request_Number,
            user_country:user_country,
            Name_of_Owner:Name_of_Owner,
            Consulate:Consulate,
            Days_Stay:Days_Stay,
            Type_of_Procedure:Type_of_Procedure,
            Validity:Validity
        },
        success: function (response) {
            // emty form
            if(response==0){
                // modal open
                jQuery('#success_allert_insert').css("display","block");
                jQuery('#success_allert_insert').css("display","flex");
                jQuery('#success_message_or_error').html("Emty form");
                setInterval(function() {
                        
                    
                    jQuery('#success_allert_insert').css("display","none");
                }, 1500);
            }
            // success insert
            if(response==1){
                jQuery('#user_name').val("");
                jQuery('#user_phone_number').val("");
                jQuery('#user_email').val("");
                // jQuery('#user_country').val("");
                jQuery('#user_passport_number').val("");
                jQuery('#user_request_number').val("");
                // modal open
                jQuery('#success_allert_insert').css("display","block");
                jQuery('#success_allert_insert').css("display","flex");
                jQuery('#success_message_or_error').html("Success");
                setInterval(function() {
                        
                    
                    jQuery('#success_allert_insert').css("display","none");
                }, 1000);
                
            }
        }
    });





}


// delete edit user
function Delete_Edit_table_data(id){
    alert("Do really want to delete ?");
    var Total_count_edit_page = jQuery('#Total_count_edit_page').html();
    
    $.ajax({
        type: "POST",
        url: "http://localhost/passport%20validation%20system/im.admin/ajax.php/delete.user.ajax.php",
        data: {
            User_id:id
        },
        success: function (response) {
            if(response==1){
                Total_count_edit_page--;
                jQuery('#Total_count_edit_page').html(Total_count_edit_page);
                jQuery('#user_table_body_'+id).css("display","none");
            }
        }
    });
}

// update user
function admin_user_UPDATE(User_ID) {
    event.preventDefault();

    // get user data from input firld form
    var Aplication_Date = jQuery('#Aplication_Date').val();
    var Passport_Number = jQuery('#Passport_Number').val();
    var Request_Number = jQuery('#Request_Number').val();
    var user_country = jQuery('#user_country').val();
    var Name_of_Owner = jQuery('#Name_of_Owner').val();
    var Consulate = jQuery('#Consulate').val();
    var Days_Stay = jQuery('#Days_Stay').val();
    var Type_of_Procedure = jQuery('#Type_of_Procedure').val();
    var Validity = jQuery('#Validity').val();

    // ajax form data insert 
    $.ajax({
        type: "POST",
        url: "http://localhost/passport%20validation%20system/im.admin/ajax.php/Update.user.ajax.php",
        data: {
            ID:User_ID,
            Aplication_Date:Aplication_Date,
            Passport_Number:Passport_Number,
            Request_Number:Request_Number,
            user_country:user_country,
            Name_of_Owner:Name_of_Owner,
            Consulate:Consulate,
            Days_Stay:Days_Stay,
            Type_of_Procedure:Type_of_Procedure,
            Validity:Validity
        },
        success: function (response) {
            
            // emty form
            if(response==0){
                // modal open
                jQuery('#success_allert_insert').css("display","block");
                jQuery('#success_allert_insert').css("display","flex");
                jQuery('#success_message_or_error').html("Emty form");
                setInterval(function() {
                    jQuery('#success_allert_insert').css("display","none");
                }, 1500);
            }
            // success insert
            if(response==1){
                // modal open
                jQuery('#user_name').val("");
                jQuery('#user_phone_number').val("");
                jQuery('#user_email').val("");
                // jQuery('#user_country').val("");
                jQuery('#user_passport_number').val("");
                jQuery('#user_request_number').val("");
                // modal open
                jQuery('#success_allert_insert').css("display","block");
                jQuery('#success_allert_insert').css("display","flex");
                jQuery('#success_message_or_error').html("Success");
                setInterval(function() {
                    jQuery('#success_allert_insert').css("display","none");
                    window.location.replace("http://localhost/passport%20validation%20system/im.admin/edit.user.php");
                }, 1000);
                
            }
        }
    });

}












