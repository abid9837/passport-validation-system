<?php
session_start();
include("../../conn.inc.php");


if(isset($_POST['admin_email']) && isset($_POST['admin_pass'])){
    $admin_email = $_POST['admin_email'];
    $admin_pass = $_POST['admin_pass'];

    $sql = "SELECT * FROM `admin` WHERE email='$admin_email' AND pass='$admin_pass' ";
    $query = mysqli_query($conn, $sql);
    if($query==true){
        $num_rows = mysqli_num_rows($query);
        $fetch_assoc = mysqli_fetch_assoc($query);
        if($num_rows==1){
            $_SESSION["admin_access"] = 1;
            $_SESSION["admin_id"] = $fetch_assoc['id'];
            echo 1;
        }
    }
    
    

}

?>