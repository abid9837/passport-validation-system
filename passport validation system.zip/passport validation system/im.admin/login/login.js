


function form_submit_validation_admin() {
    event.preventDefault();

    // user inputs
    var admin_email = jQuery('#admin_email').val();
    var admin_pass = jQuery('#admin_pass').val();
    
    // ajax request
    $.ajax({
        type: "POST",
        url: "http://localhost/passport%20validation%20system/im.admin/login/login.ajax.php",
        data: {
            admin_email:admin_email,
            admin_pass:admin_pass
        },
        success: function (response) {
            // success login
            if(response==1){
                jQuery('#Login_success_or_not').html("Login Success");
                setInterval(function() {
                    jQuery('#Login_success_or_not').html("");
                    window.location.replace("../");
                }, 2000);
            }
            // faield login
            if(response==0){
                jQuery('#Login_success_or_not').html("wrong credentials");
                jQuery('#Login_success_or_not').css("color","#dc3545");
                setInterval(function() {
                    jQuery('#Login_success_or_not').html("");
                }, 2000);
                
            }
        }
    });
}
