



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Login</title>
    <link rel="icon" type="image/x-icon" href="../../asset/img/icon.ico">
    <link rel="stylesheet" href="./login.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
</head>
<body>
    

<div id="login_form_container">
    <div class="Login_container_inner">
        <form onsubmit="form_submit_validation_admin();">
            <div class="mb-3">
                <label style="font-size: 20px" class="form-label">Log Into Admin Pannel</label>
               
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email address</label>
                <input id="admin_email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
            </div>
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input id="admin_pass" type="password" class="form-control" id="exampleInputPassword1" required>
            </div>
            <div class="form_success_submit">
                <button type="submit" class="btn btn-primary">Login</button>
                <p id="Login_success_or_not"></p>
            </div>
            
        </form>
    </div>
</div>



<script src="./login.js"></script>
</body>
</html>