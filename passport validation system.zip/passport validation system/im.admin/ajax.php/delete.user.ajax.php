<?php
include("../../conn.inc.php");

if(isset($_POST['User_id'])){
    $User_id = $_POST['User_id'];
    $sql = "DELETE FROM passposrt_users_info WHERE id='$User_id' ";
    $query = mysqli_query($conn, $sql);
    if($query==true){
        echo 1;
    }
}


?>