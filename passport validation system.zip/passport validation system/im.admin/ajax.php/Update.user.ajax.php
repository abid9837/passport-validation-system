<?php
include("../../conn.inc.php");


if( 
    (isset($_POST['Aplication_Date'])) && (isset($_POST['Passport_Number'])) && 
    (isset($_POST['Request_Number'])) && (isset($_POST['user_country'])) &&
    (isset($_POST['Name_of_Owner'])) && (isset($_POST['Consulate'])) &&
    (isset($_POST['Days_Stay'])) && (isset($_POST['Type_of_Procedure'])) && 
    (isset($_POST['Validity']))
    &&
    !empty($_POST['Aplication_Date']) && !empty($_POST['Passport_Number']) &&
    !empty($_POST['Request_Number']) &&!empty($_POST['user_country']) &&
    !empty($_POST['Name_of_Owner']) && !empty($_POST['Consulate']) &&
    !empty($_POST['Days_Stay']) && !empty($_POST['Type_of_Procedure']) &&
    !empty($_POST['Validity']) 
 ){
    $ID = $_POST['ID'];
    $Aplication_Date = htmlspecialchars($_POST['Aplication_Date']);
    $Passport_Number = htmlspecialchars($_POST['Passport_Number']);
    $Request_Number = htmlspecialchars($_POST['Request_Number']);
    $user_country = htmlspecialchars($_POST['user_country']);
    $Name_of_Owner = htmlspecialchars($_POST['Name_of_Owner']);
    $Consulate = htmlspecialchars($_POST['Consulate']);
    $Days_Stay = htmlspecialchars($_POST['Days_Stay']);
    $Type_of_Procedure = htmlspecialchars($_POST['Type_of_Procedure']);
    $Validity = htmlspecialchars($_POST['Validity']);



    $sql = "UPDATE `passposrt_users_info`SET 
        submit_date='$curernt_date', aplication_date='$Aplication_Date', passport_number='$Passport_Number', request_number='$Request_Number',
        country='$user_country', name_of_owner='$Name_of_Owner', consulate='$Consulate', days_stay='$Days_Stay', type_of_procedure='$Type_of_Procedure', validity='$Validity'
        WHERE id='$ID'
    ";



    $query =  mysqli_query($conn, $sql);
    if($query==true){
        echo 1;
    }
    
}else{
    echo 0;
}


?>